# Student Portfolio — Vercel-ready static + PHP source

**Both `index.php` and `index.html` remain in the root folder.** The Vercel website uses the rendered static copy in `public/`, while the original PHP source and `includes/` remain available for XAMPP/local development. No `Dockerfile.vercel`, `vercel.json`, or `.gitignore` is needed.

## Project structure

```
student-portfolio/
├── index.php        # original PHP source
├── index.html       # generated HTML copy
├── includes/        # PHP components, not publicly deployed
├── assets/          # original images, documents, font folder
├── css/             # original styles
├── js/              # original scripts
├── public/          # Vercel serves this directory ONLY
│   ├── index.html
│   ├── assets/
│   ├── css/
│   └── js/
└── README.md
```

## How to deploy using Vercel and GitHub

1. Create a repository on GitHub and upload **all files INSIDE `student-portfolio/`** to the repo root. If you upload the outer `student-portfolio/` folder itself, set Vercel's Root Directory to `student-portfolio`.
2. Open Vercel → Add New → Project → Import your GitHub repository.
3. Select **Framework Preset: Other**.
4. Use the repo root (`./`) for **Root Directory**, or choose `student-portfolio` if nested.
5. Set **Output Directory: `public`** (Vercel normally uses it automatically for the Other preset).
6. **Build Command: none**. If a build command is supplied by default, enable Override and leave it empty.
7. Click Deploy. Then test all four project links, the auto-slideshow, the five certificate previews, dark mode, resume, contact form and responsive view.

The PHP files are NOT used by the Vercel site. Keep `public` as Output Directory so `index.php` and `includes/` aren't publicly served.

## How to update content

The HTML is a snapshot of PHP output. Editing `index.php` does **not** update the static page automatically.

After editing PHP while using XAMPP or PHP CLI:

- From the project root, run `php index.php > index.html` (on Windows, you can use XAMPP's `C:\xampp\php\php.exe`).
- Copy `index.html` into `public/index.html`.
- Copy any updated `assets/`, `css/` and `js/` files into the matching folders under `public/`.
- Commit and push to your repo to trigger a Vercel redeployment.

For local PHP development, open `http://localhost/student-portfolio/index.php` through XAMPP. For the Vercel version, a static local web server can serve `public/`.

## Fonts and images

`assets/images/` and `assets/fonts/` are **separate directories**, both in the source and in `public/`. This ZIP retains the font folder, but the incoming portfolio ZIP did not contain local Inter `.woff2` binaries. Online Inter fallback is configured. If you restore the Inter font files from the original upload, copy them into both `assets/fonts/` and `public/assets/fonts/`.

## Contact form

The form submits to Web3Forms from the browser; no PHP backend is required at deploy time. Verify the embedded access key works for your Web3Forms account. Environment variables read by `index.php` during local rendering do not update static HTML automatically. To change the key, regenerate both copies of the HTML.

## Deployment status

This archive is prepared for deployment but has **not** been deployed to your Vercel account here. The original PHP files, HTML versions, responsive styling, and existing portfolio content are retained.
